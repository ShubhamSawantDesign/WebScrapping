import requests as request
import numpy as np
from bs4 import BeautifulSoup
import csv



# Step 1: Get the HTML

url = "https://www.us-cert.gov/ncas/alerts/2020"
r = request.get(url)
htmlContent = r.content
finaldata=[]

# the above code will connect to target website

#Step 2:
#Here we will use beautiful soupe for harvesting information
soup = BeautifulSoup(htmlContent, 'html.parser')

outer_blocks = soup.find_all("div", {"class": "views-field views-field-title"})

#Step 3: HTML Traversal 
# here will fethc the targeted table data and use string slicing to get the data into a array
for block in outer_blocks:
          ids = block.text
          nameofthreat = block.text 
          datawritten=[ids[0:8],nameofthreat[12:185]]
          if datawritten not in datawritten:
                finaldata.append(datawritten) 
#Step 4: Write data to CSV

#the above code will generate output 
with open('output.csv','w') as f:
    writer = csv.writer(f, delimiter=",")
    writer.writerow(["Alert ID","Title of Alert"])
    writer.writerows(finaldata)

        
